var Menu = {

    preload : function() {
            game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
            game.scale.pageAlignHorizontally = true;
            game.scale.pageAlignVertically = true;
            game.stage.backgroundColor = 'blue'; 

        game.load.image('menu', 'assets/start.png');
         
    },

    create: function () {
     
        this.add.sprite(0, 0, 'menu');
             this.add.button(0, 0, 'menu', this.startGame, this);
    },

    startGame: function () {

   
        this.state.start('Game');

    }


};