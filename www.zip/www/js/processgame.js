var process = function() {
	   "use strict";
        return {
 createStars : function(time) {
    setInterval(function() {
        stars= star.create(Math.random()*900, -100, "bird");
        stars.body.gravity.y = 60;
 

        stars.body.collideWorldBounds = true;
    },time);
}, 

 scoreMe : function(player, devil) {
    
    // Removes the star from the screen
  
    score += 1; 


    if(process.getScore()<=score){
        process.saveScore(score);
        bestScoreText.text= "Score:  "+score;
    }
    
    scoreText.text = 'Score: ' + score;
   soundeffects.play()
},
 
audio : function(time){
    setInterval(function(){
        bgAudio.play();
        },time)
 

},
createRinas : function(time) {
    setInterval(function() {
        aswang= rina.create(900,250, "demon");
     
         aswang.body.gravity.y = -30;

          aswang= rina.create(900,1050, "demon");
        aswang.body.gravity.x = -30;
         aswang.body.gravity.y = -30;
            aswang= rina.create(900,850, "demon");
        aswang.body.gravity.x = -30;
         aswang.body.gravity.y = -30;

          aswang= rina.create(900,550, "demon");
        aswang.body.gravity.x = -30;
         aswang.body.gravity.y = -30;

           aswang= rina.create(900,2800, "demon");
        aswang.body.gravity.x = -30;
         aswang.body.gravity.y = -30;

           aswang= rina.create(900,2500, "demon");
                 aswang.body.gravity.y = -30;

                  aswang= rina.create(900,1500, "demon");
                 aswang.body.gravity.x = -30;

                  aswang= rina.create(900,1200, "demon");
                 aswang.body.gravity.x = -30;
                    aswang= rina.create(900,2200, "demon");
                 aswang.body.gravity.y = -30;

 aswang= rina.create(420,2700, "demon");
                 aswang.body.gravity.y = -30;

                   aswang.body.gravity.x = -60;


 aswang= rina.create(420,2700, "demon");
                 aswang.body.gravity.y = -40;

                



        aswang.body.collideWorldBounds = false;
    },time);
}, 
killPlayer : function (player, rina) {
    player.kill();
    game.state.start("Gameover");
},
restart : function(){
    game.state.start("Game");
},

pause: function(){
    game.paused= true;
    pauseText.text = 'tap to unpause';
},
     unpause:  function (event){
        // Only act if paused
   game.paused = false;
    pauseText.text = '';
},

 killMe : function(player, platforms){
    player.kill();
    game.state.start("Gameover");

 },

 jump : function (){
         player.body.velocity.y = -350;
 },
saveScore : function(score){
    localStorage.setItem("gameScore",score);
},

 getScore : function(){
    return (localStorage.getItem("gameScore") == null || localStorage.getItem("gameScore") == "")?0:localStorage.getItem("gameScore");
   /* var data = localStorage.getItem("gameData");
    if(data == null || data == "") {
        data = 0;
    }*/
},
}
}();