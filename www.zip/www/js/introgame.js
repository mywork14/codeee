
var w = 600;
var h = 600;
var platform,bg,crystal,ghost,platforms,scoreText,gameOverText,ghosts,crystals,bestText;
var platform,bg,crystal,ghost,platforms,scoreText,gameOverText,ghosts,crystals;
var player;
var platforms;
var cursors, ledge;

var basicGame;
var stars , star;
var anons;
var score = 0;
var scoreText;
var demonyos;
var bestScoreText;
var bgAudio1 , bgAudio2 , bgAudio3;
var soundeffects;
var btn;
var start;
var bg1, bg2, bg3, bg4;
var audio, audio1, audio2;
game = new Phaser.Game(w, h, Phaser.CANVAS, '');

game.state.add('Menu', Menu);

/*// Adding the Game state.
game.state.add('Game', Game);*/

game.state.start('Menu');
/*var basicGame = function(){
}
*/
game.state.add('Game');
game.state.add('Gameover');

/*var basicGame = function(){
}

*/