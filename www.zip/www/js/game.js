var josuha;
var text;
var satan;
var left = false;
var right = false;
var aswang;
var score = 0;
var scoreText;
var demonyos;
var bestScoreText;
var Game = {
 preload: function() {
 
            game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
            game.scale.pageAlignHorizontally = true;
            game.scale.pageAlignVertically = true;
            game.stage.backgroundColor = 'blue'; 
   
            game.load.image("bird", 'assets/bird.png');

              game.load.image("sky", 'assets/water.jpg');
                game.load.image("demon", 'assets/demonyo.png');
            game.load.spritesheet("tao", 'assets/rina.png',32,49);
             game.load.image("pause", 'assets/pause.png');
            game.load.image("restart", 'assets/restart.png');
             game.load.image("bg1", 'assets/road.jpg');
                    game.load.image("cloud", 'assets/cloud.png');
                         game.load.image("wall", 'assets/wall.jpg');
     
               game.load.image("bg3", 'assets/trees.png');
  game.load.image("left", 'assets/left.png');
                         game.load.image("right", 'assets/right.png');
                          game.load.image("jump", 'assets/jump.png');
     
      
            game.load.audio("bgMusic","music/rina.wav");
            game.load.audio("soundeffects","music/jump.mp3");
           

},
 create: function() {

    //  We're going to be using physics, so enable the Arcade Physics system
            game.physics.startSystem(Phaser.Physics.ARCADE);
              game.world.setBounds(0,0,800,3000);
            //  A simple background for our game
                  game.add.sprite(0, 0, 'sky');

            platforms = game.add.group();
            platforms.enableBody = true;

            var ledge = platforms.create(0,2950,"wall");
            ledge.body.immovable=true;

            bgAudio = game.add.audio("bgMusic");
            bgAudio.play();
            process.audio(13000);

            soundeffects = game.add.audio("soundeffects");  
            process.createRinas(5000);
            rina = game.add.group();
            rina.enableBody=true;

            var joshua = rina.create(420,2700,"demon");
            joshua.immovable=true;

            devil = game.add.group();
            devil.enableBody=true;

        

      

          var satan = devil.create(320,2800, "cloud");
      satan.body.immovable = true;

       var satan = devil.create(120,2600, "cloud");
      satan.body.immovable = true;
         
          var satan = devil.create(320,2400, "cloud");
      satan.body.immovable = true;
         
          var satan = devil.create(120,2200, "cloud");
      satan.body.immovable = true;

          var satan = devil.create(400,2000, "cloud");
      satan.body.immovable = true;
         
          var satan = devil.create(100,1800, "cloud");
      satan.body.immovable = true;


          var satan = devil.create(250,1600, "cloud");
      satan.body.immovable = true;

         var satan = devil.create(400,1400, "cloud");
      satan.body.immovable = true;
         var satan = devil.create(200,1200, "cloud");
      satan.body.immovable = true;
         
            var satan = devil.create(400,1000, "cloud");
      satan.body.immovable = true;

          var satan = devil.create(100,800, "cloud");
      satan.body.immovable = true;


          var satan = devil.create(300,600, "cloud");
      satan.body.immovable = true;
         
            var satan = devil.create(400,400, "cloud");
      satan.body.immovable = true;

          var satan = devil.create(100,200, "cloud");
      satan.body.immovable = true;
             buttonleft = game.add.button(66, 500, 'left');
                buttonleft.anchor.setTo(0.5, 0.5);
                buttonleft.fixedToCamera = true;
                buttonleft.events.onInputOver.add(function(){left=true;});
                buttonleft.events.onInputOut.add(function(){left=false;});
                buttonleft.events.onInputDown.add(function(){left=true;});
                buttonleft.events.onInputUp.add(function(){left=false;});
              
             buttonright = game.add.button(200, 500, 'right');
                buttonright.anchor.setTo(0.5, 0.5);
                buttonright.fixedToCamera = true;
                buttonright.events.onInputOver.add(function(){right=true;});
                buttonright.events.onInputOut.add(function(){right=false;});
                buttonright.events.onInputDown.add(function(){right=true;});
                buttonright.events.onInputUp.add(function(){right=false;});
         
           btn = game.add.button(500,460,"jump",process.jump);
                  btn.fixedToCamera=true;
            
         
        
            game.input.onDown.add(process.unpause, self);
         btn = game.add.button(16,60,"pause",process.pause);
            btn.fixedToCamera=true;


         btn = game.add.button(450,30,"restart",process.restart);
          btn.fixedToCamera=true;         
         

         
        
            // The player and its settings
            player = game.add.sprite(320, game.world.height - 400, 'tao');

            //  We need to enable physics on the player
            game.physics.arcade.enable(player);
               
          player.body.bounce.y = 0.2;
            player.body.gravity.y = 300;
            player.body.collideWorldBounds = true;

            //  Player physics properties. Give the little guy a slight bounce.
        


   
            player.animations.add('left', [4, 5, 6, 7],10, true); 
            player.animations.add('right', [8, 9, 10, 11],10, true); 

            //  Finally some stars to collect
     
    
 bestScoreText = game.add.text(16,45, 'Best Game Score: '+process.getScore(),{fill:'white'});
   bestScoreText.fixedToCamera = true;
            scoreText = game.add.text(16, 16, 'Score: 0', { fontSize: '32px', fill: 'white' });
             pauseText = game.add.text(250, 350, '', { fontSize: '500px', fill: 'darkblue' });
    pauseText.fixedToCamera = true;
           
            messageText = game.add.text(180, 180, '', { fontSize: '120px', fill: 'red' });
             game.camera.follow(player, Phaser.Camera.FOLLOW_TOPDOWN);
          
             scoreText.fixedToCamera = true;
              messageText.fixedToCamera = true;
                game.camera.follow(player, Phaser.Camera.FOLLOW_LOCKON);


            //  Our controls.
            cursors = game.input.keyboard.createCursorKeys();
           
            
        },

update: function() {

    //  Collide the player and the stars with the platforms
     game.physics.arcade.collide(player,rina, process.killPlayer, null, this);
    game.physics.arcade.collide(player,devil, process.scoreMe, null, this);
        game.physics.arcade.collide(player,platforms, process.killMe, null,this);
     game.physics.arcade.overlap(player,platforms, process.killMe, null, this);




    //  Checks to see if the player overlaps with any of the stars, if he does call the collectStar function


      


    //  Reset the players velocity (movement)
    if (left) {
               
                player.body.velocity.x=-120;
                player.animations.play('left');
            }
            else if (right) {
          
                player.body.velocity.x=120;
                player.animations.play('right');
            } 
            else {
                   player.body.velocity.x=0;

              player.frame = 1;
            }

            if (game.input.currentPointers == 0 && !game.input.activePointer.isMouse){ fire=false; right=false; left=false; duck=false; jump=false;} //this 
        }
}
game.state.add("Game" ,Game, false);